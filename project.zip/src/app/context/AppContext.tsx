import React, { createContext, useContext, useState, useCallback } from "react";

export type Status = "planned" | "in_progress" | "completed" | "cancelled";
export type Priority = "low" | "medium" | "high";

export interface RoadmapItem {
  id: string;
  title: string;
  description: string;
  status: Status;
  priority: Priority;
  category: string;
  quarter: string;
  startDate: string;
  endDate: string;
}

interface User {
  email: string;
  initial: string;
}

interface Team {
  name: string;
  joinCode: string;
}

interface AppState {
  user: User | null;
  team: Team | null;
  items: RoadmapItem[];
  loading: boolean;
  setUser: (user: User | null) => void;
  setTeam: (team: Team | null) => void;
  addItem: (item: Omit<RoadmapItem, "id">) => void;
  updateItem: (id: string, item: Partial<RoadmapItem>) => void;
  deleteItem: (id: string) => void;
  setLoading: (v: boolean) => void;
  logout: () => void;
}

const AppContext = createContext<AppState | null>(null);

function generateCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 8; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

function generateId(): string {
  return Math.random().toString(36).substring(2, 11);
}

const sampleItems: RoadmapItem[] = [
  { id: generateId(), title: "User authentication flow", description: "Implement OAuth2 and email/password login with session management", status: "completed", priority: "high", category: "Auth", quarter: "Q1 2025", startDate: "2025-01-15", endDate: "2025-02-28" },
  { id: generateId(), title: "Dashboard analytics widgets", description: "Build real-time analytics charts for user engagement metrics", status: "in_progress", priority: "high", category: "UI", quarter: "Q1 2025", startDate: "2025-02-01", endDate: "2025-03-31" },
  { id: generateId(), title: "API rate limiting", description: "Add rate limiting middleware to protect backend endpoints", status: "in_progress", priority: "medium", category: "Backend", quarter: "Q2 2025", startDate: "2025-04-01", endDate: "2025-04-30" },
  { id: generateId(), title: "Dark mode support", description: "Implement system-aware dark mode toggle across all components", status: "planned", priority: "medium", category: "UI", quarter: "Q2 2025", startDate: "2025-05-01", endDate: "2025-06-15" },
  { id: generateId(), title: "Mobile responsive redesign", description: "Redesign layouts for optimal mobile and tablet experience", status: "planned", priority: "high", category: "UI", quarter: "Q2 2025", startDate: "2025-04-15", endDate: "2025-06-30" },
  { id: generateId(), title: "Webhook integrations", description: "Support Slack, Discord, and custom webhook notifications", status: "planned", priority: "low", category: "Integrations", quarter: "Q3 2025", startDate: "2025-07-01", endDate: "2025-08-31" },
  { id: generateId(), title: "CSV data export", description: "Allow users to export roadmap data to CSV format", status: "completed", priority: "low", category: "Features", quarter: "Q1 2025", startDate: "2025-01-10", endDate: "2025-01-25" },
  { id: generateId(), title: "Legacy API v1 deprecation", description: "Deprecate and remove v1 API endpoints after migration period", status: "cancelled", priority: "medium", category: "Backend", quarter: "Q1 2025", startDate: "2025-01-01", endDate: "2025-03-31" },
  { id: generateId(), title: "Multi-language support", description: "Add i18n framework and translate UI to Spanish, French, German", status: "planned", priority: "low", category: "Features", quarter: "Q4 2025", startDate: "2025-10-01", endDate: "2025-12-31" },
  { id: generateId(), title: "Team permissions system", description: "Role-based access control for team members with granular permissions", status: "in_progress", priority: "high", category: "Auth", quarter: "Q2 2025", startDate: "2025-04-01", endDate: "2025-05-31" },
];

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [team, setTeam] = useState<Team | null>(null);
  const [items, setItems] = useState<RoadmapItem[]>(sampleItems);
  const [loading, setLoading] = useState(false);

  const addItem = useCallback((item: Omit<RoadmapItem, "id">) => {
    setItems((prev) => [...prev, { ...item, id: generateId() }]);
  }, []);

  const updateItem = useCallback((id: string, updates: Partial<RoadmapItem>) => {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...updates } : i)));
  }, []);

  const deleteItem = useCallback((id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setTeam(null);
  }, []);

  const createTeam = useCallback((name: string) => {
    setTeam({ name, joinCode: generateCode() });
  }, []);

  return (
    <AppContext.Provider
      value={{ user, team, items, loading, setUser, setTeam: (t) => { if (t) setTeam(t); else setTeam(null); }, addItem, updateItem, deleteItem, setLoading, logout }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

export function generateTeamCode(): string {
  return generateCode();
}
